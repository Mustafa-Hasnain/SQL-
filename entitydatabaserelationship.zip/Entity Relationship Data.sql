create database db_EntitySupplierRelationship

use db_EntitySupplierRelationship

create table Supplier(
delivery_id int Primary Key identity(1,1),
delivery_date varchar(50),
supplier_id int
)

Insert into Supplier values('1st June', 1)
Insert into Supplier values('2nd June', 2)
Insert into Supplier values('3rd June', 3)
Insert into Supplier values('4th June', 4)

Select * from Supplier

create table Delivery(
delivery_id int foreign key references Supplier(delivery_id),
delivery_date varchar(50),
supplier_id int 
)

insert into Delivery(delivery_date,supplier_id) values('5th June',1)
insert into Delivery(delivery_date,supplier_id) values('6th June',2)
insert into Delivery(delivery_date,supplier_id) values('7th June',3)
insert into Delivery(delivery_date,supplier_id) values('8th June',4)

Select * from Delivery

insert into Delivery(delivery_id) values(1)
insert into Delivery(delivery_id) values(2)
insert into Delivery(delivery_id) values(3)
insert into Delivery(delivery_id) values(4)

delete delivery where delivery_id=1
delete delivery where delivery_id=2
delete delivery where delivery_id=3
delete delivery where delivery_id=4


update Delivery set delivery_id = 1 where delivery_date='5th June'
update Delivery set delivery_id = 2 where delivery_date='6th June'
update Delivery set delivery_id = 3 where delivery_date='7th June'
update Delivery set delivery_id = 4 where delivery_date='8th June'

create table Product(
product_id int Primary Key identity(1,1),
supplier_id int
)

insert into Product values(1)
insert into Product values(2)
insert into Product values(3)
insert into Product values(4) 

select * from Product


create table Branch(
branch_id int Primary Key
)

insert into Branch values(1)
insert into Branch values(2)
insert into Branch values(3)
insert into Branch values(4) 

select * from Branch

create table Headquaters(
headquarters_id int Primary Key identity(1,1),
branch_id int foreign key references Branch(branch_id)
)

select * from Headquaters

create table Orders(
order_id int Primary Key identity(1,1),
order_date varchar(50),
headquarters_id int foreign key references Headquaters(headquarters_id)
)

select * from Orders

create table OrderDetail(
order_detail_id int Primary Key identity(1,1),
product_id int foreign key references Product(product_id),
order_id int foreign key references Orders(order_id),
product_quantity varchar(50)
)

select * from OrderDetail

create table OrderDetailDelivery(
delivery_id int foreign key references Supplier(delivery_id),
order_id int foreign key references Orders(order_id),
order_detail_id int Primary Key
)

